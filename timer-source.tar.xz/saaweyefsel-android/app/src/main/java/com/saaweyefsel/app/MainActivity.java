package com.saaweyefsel.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST_CODE = 501;
    private static final int NOTIFICATION_REQUEST_CODE = 502;
    private static final int BACKGROUND = Color.rgb(10, 21, 39);
    private static final int SURFACE = Color.rgb(23, 39, 63);
    private static final int ACCENT = Color.rgb(79, 215, 187);
    private static final int WHITE = Color.rgb(241, 246, 252);
    private static final int MUTED = Color.rgb(174, 190, 211);

    private EditText minuteInput;
    private TextView timeText;
    private TextView stateText;
    private TextView helperText;
    private Button startButton;
    private Button stopButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int pendingMinutes = 60;
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() {
            refreshState();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST_CODE);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView badge = label("●  بدون روت • بدون حساب", 14, ACCENT, Typeface.BOLD);
        root.addView(badge, fullWidth(0, 12));
        TextView title = label("ساعة ويفصل", 34, WHITE, Typeface.BOLD);
        root.addView(title, fullWidth(0, 3));
        TextView subtitle = label("حدد الوقت، وسيتم حجب الإنترنت تلقائيًا عندما ينتهي.", 16, MUTED, Typeface.NORMAL);
        root.addView(subtitle, fullWidth(0, 23));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(18), dp(27), dp(18), dp(25));
        card.setBackground(round(SURFACE, 26));
        root.addView(card, fullWidth(0, 16));

        stateText = label("جاهز للبدء", 17, ACCENT, Typeface.BOLD);
        stateText.setGravity(Gravity.CENTER);
        card.addView(stateText, fullWidth(0, 8));
        timeText = label("01:00:00", 40, WHITE, Typeface.BOLD);
        timeText.setGravity(Gravity.CENTER);
        timeText.setTextDirection(View.TEXT_DIRECTION_LTR);
        card.addView(timeText, fullWidth(0, 8));
        helperText = label("الإنترنت يعمل حاليًا", 14, MUTED, Typeface.NORMAL);
        helperText.setGravity(Gravity.CENTER);
        card.addView(helperText, fullWidth(0, 6));

        TextView picker = label("المدة بالدقائق", 16, WHITE, Typeface.BOLD);
        root.addView(picker, fullWidth(0, 11));
        minuteInput = new EditText(this);
        minuteInput.setSingleLine(true);
        minuteInput.setText("60");
        minuteInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        minuteInput.setTextColor(WHITE);
        minuteInput.setHintTextColor(MUTED);
        minuteInput.setTextSize(24);
        minuteInput.setGravity(Gravity.CENTER);
        minuteInput.setSelectAllOnFocus(true);
        minuteInput.setBackground(round(SURFACE, 16));
        root.addView(minuteInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));

        LinearLayout presets = new LinearLayout(this);
        presets.setGravity(Gravity.CENTER);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(presets, fullWidth(12, 18));
        int[] durations = {10, 30, 60, 120};
        String[] words = {"10 د", "30 د", "ساعة", "ساعتين"};
        for (int i = 0; i < durations.length; i++) {
            final int mins = durations[i];
            TextView chip = label(words[i], 13, ACCENT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(round(SURFACE, 13));
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(0, dp(44), 1);
            chipParams.setMargins(dp(3), 0, dp(3), 0);
            presets.addView(chip, chipParams);
            chip.setOnClickListener(v -> minuteInput.setText(String.valueOf(mins)));
        }

        startButton = button("ابدأ العدّاد", ACCENT, BACKGROUND);
        root.addView(startButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        startButton.setOnClickListener(v -> requestStart());

        stopButton = button("إلغاء / تشغيل الإنترنت", Color.rgb(177, 55, 79), WHITE);
        root.addView(stopButton, fullWidth(12, 0));
        stopButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, BlockVpnService.class);
            intent.setAction(BlockVpnService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "تم طلب إيقاف الحظر وإلغاء العدّاد", Toast.LENGTH_SHORT).show();
            handler.postDelayed(this::refreshState, 250);
        });

        TextView warning = label("⚠ التطبيق لا يطفئ زر بيانات الشريحة. عند انتهاء العدّاد، يستخدم VPN محليًا لحجب الإنترنت (بيانات الهاتف والواي فاي). لا يرسل بياناتك إلى أي خادم. ويمكنك إلغاء الحظر في أي وقت.", 14, MUTED, Typeface.NORMAL);
        warning.setPadding(dp(3), dp(22), dp(3), dp(4));
        root.addView(warning, fullWidth(0, 0));
    }

    private void requestStart() {
        String raw = minuteInput.getText().toString().trim();
        int mins;
        try { mins = Integer.parseInt(raw); }
        catch (NumberFormatException ex) {
            Toast.makeText(this, "اكتب عدد دقائق صحيح", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mins < 1 || mins > 1440) {
            Toast.makeText(this, "اختر مدة من دقيقة إلى 24 ساعة", Toast.LENGTH_LONG).show();
            return;
        }
        pendingMinutes = mins;
        Intent consent = VpnService.prepare(this);
        if (consent == null) startTimerService();
        else startActivityForResult(consent, VPN_REQUEST_CODE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) startTimerService();
            else Toast.makeText(this, "يجب السماح باتصال VPN المحلي لكي يعمل الحجب", Toast.LENGTH_LONG).show();
        }
    }

    private void startTimerService() {
        Intent intent = new Intent(this, BlockVpnService.class);
        intent.setAction(BlockVpnService.ACTION_START);
        intent.putExtra(BlockVpnService.EXTRA_DURATION_MINUTES, pendingMinutes);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            handler.postDelayed(this::refreshState, 300);
        } catch (RuntimeException e) {
            Toast.makeText(this, "تعذّر بدء العدّاد: راجع أذونات التطبيق", Toast.LENGTH_LONG).show();
        }
    }

    private void refreshState() {
        SharedPreferences prefs = getSharedPreferences(BlockVpnService.PREFS, MODE_PRIVATE);
        String state = prefs.getString(BlockVpnService.KEY_STATE, "idle");
        long endsAt = prefs.getLong(BlockVpnService.KEY_END_EPOCH, 0);
        if ("countdown".equals(state)) {
            long leftMs = Math.max(0, endsAt - System.currentTimeMillis());
            long seconds = (leftMs + 999) / 1000;
            stateText.setText("العدّاد شغّال");
            timeText.setText(formatTime(seconds));
            helperText.setText("هيتم حجب الإنترنت لما العدّاد يخلص");
            startButton.setEnabled(false);
            startButton.setAlpha(.55f);
            stopButton.setEnabled(true);
        } else if ("blocked".equals(state)) {
            stateText.setText("تم حجب الإنترنت");
            timeText.setText("00:00:00");
            helperText.setText("اضغط تشغيل الإنترنت لإلغاء VPN المحلي");
            startButton.setEnabled(false);
            startButton.setAlpha(.55f);
            stopButton.setEnabled(true);
        } else if ("error".equals(state)) {
            stateText.setText("تعذّر حجب الإنترنت");
            timeText.setText("--:--:--");
            helperText.setText("افتح التطبيق وأعد المحاولة، أو راجع إذن VPN");
            startButton.setEnabled(true);
            startButton.setAlpha(1f);
            stopButton.setEnabled(true);
        } else {
            stateText.setText("جاهز للبدء");
            timeText.setText("01:00:00");
            helperText.setText("الإنترنت يعمل حاليًا");
            startButton.setEnabled(true);
            startButton.setAlpha(1f);
            stopButton.setEnabled(false);
        }
    }

    private static String formatTime(long totalSeconds) {
        return String.format(Locale.US, "%02d:%02d:%02d", totalSeconds / 3600,
                (totalSeconds % 3600) / 60, totalSeconds % 60);
    }
    private TextView label(String text, int sp, int color, int style) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(sp);
        view.setTypeface(Typeface.create("sans-serif", style));
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        return view;
    }
    private Button button(String text, int backgroundColor, int foregroundColor) {
        Button view = new Button(this);
        view.setAllCaps(false);
        view.setText(text);
        view.setTextSize(17);
        view.setTypeface(null, Typeface.BOLD);
        view.setTextColor(foregroundColor);
        view.setBackground(round(backgroundColor, 17));
        return view;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private LinearLayout.LayoutParams fullWidth(int marginTop, int marginBottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(marginTop), 0, dp(marginBottom));
        return p;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshTask);
        handler.post(refreshTask);
    }
    @Override protected void onPause() {
        handler.removeCallbacks(refreshTask);
        super.onPause();
    }
}
