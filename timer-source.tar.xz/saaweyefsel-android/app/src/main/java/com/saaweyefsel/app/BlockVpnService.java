package com.saaweyefsel.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

public class BlockVpnService extends VpnService {
    public static final String ACTION_START = "com.saaweyefsel.app.START";
    public static final String ACTION_STOP = "com.saaweyefsel.app.STOP";
    public static final String EXTRA_DURATION_MINUTES = "duration_minutes";
    public static final String PREFS = "timer_state";
    public static final String KEY_STATE = "state";
    public static final String KEY_END_EPOCH = "end_epoch_ms";
    private static final String CHANNEL_ID = "internet_timer";
    private static final int NOTIFICATION_ID = 112;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean reading = new AtomicBoolean(false);
    private ParcelFileDescriptor tunnel;
    private Thread dropThread;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            SharedPreferences prefs = prefs();
            String state = prefs.getString(KEY_STATE, "idle");
            if ("countdown".equals(state)) {
                if (System.currentTimeMillis() >= prefs.getLong(KEY_END_EPOCH, 0)) {
                    activateBlock();
                } else {
                    handler.postDelayed(this, 1000);
                }
            } else if ("blocked".equals(state) && tunnel == null) {
                activateBlock();
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            prefs().edit().putString(KEY_STATE, "idle").remove(KEY_END_EPOCH).apply();
            handler.removeCallbacks(tick);
            closeTunnel();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action)) {
            int minutes = intent.getIntExtra(EXTRA_DURATION_MINUTES, 60);
            if (minutes < 1 || minutes > 1440) {
                stopSelf();
                return START_NOT_STICKY;
            }
            long deadline = System.currentTimeMillis() + (minutes * 60_000L);
            closeTunnel();
            prefs().edit().putString(KEY_STATE, "countdown").putLong(KEY_END_EPOCH, deadline).apply();
        }

        String state = prefs().getString(KEY_STATE, "idle");
        if (!"countdown".equals(state) && !"blocked".equals(state)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        Notification notification = buildNotification("blocked".equals(state));
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        handler.removeCallbacks(tick);
        handler.post(tick);
        return START_STICKY;
    }

    private void activateBlock() {
        if (tunnel != null) return;
        try {
            Builder vpn = new Builder()
                    .setSession("ساعة ويفصل - إيقاف الإنترنت")
                    .setMtu(1500)
                    .addAddress("10.73.0.1", 32)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("10.73.0.1")
                    .addAddress("fd73::1", 128)
                    .addRoute("::", 0)
                    .addDnsServer("fd73::1");
            ParcelFileDescriptor newTunnel = vpn.establish();
            if (newTunnel == null) {
                markError();
                return;
            }
            tunnel = newTunnel;
            reading.set(true);
            dropThread = new Thread(() -> {
                try (InputStream input = new FileInputStream(newTunnel.getFileDescriptor())) {
                    byte[] packet = new byte[32767];
                    while (reading.get() && input.read(packet) >= 0) {
                        // Deliberately discard all packets. Nothing leaves this device.
                    }
                } catch (IOException ignored) {
                    // The descriptor is normally closed when the user stops the block.
                }
            }, "internet-packet-dropper");
            dropThread.start();
            prefs().edit().putString(KEY_STATE, "blocked").apply();
            notificationManager().notify(NOTIFICATION_ID, buildNotification(true));
        } catch (Exception error) {
            markError();
        }
    }

    private void markError() {
        prefs().edit().putString(KEY_STATE, "error").apply();
        closeTunnel();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void closeTunnel() {
        reading.set(false);
        ParcelFileDescriptor old = tunnel;
        tunnel = null;
        if (old != null) {
            try { old.close(); } catch (IOException ignored) { }
        }
        if (dropThread != null) {
            dropThread.interrupt();
            dropThread = null;
        }
    }

    @Override public void onRevoke() {
        prefs().edit().putString(KEY_STATE, "idle").remove(KEY_END_EPOCH).apply();
        handler.removeCallbacks(tick);
        closeTunnel();
        stopSelf();
        super.onRevoke();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        closeTunnel();
        super.onDestroy();
    }

    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }
    private NotificationManager notificationManager() { return getSystemService(NotificationManager.class); }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "مؤقت الإنترنت", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("العد التنازلي وحالة حجب الإنترنت");
        notificationManager().createNotificationChannel(channel);
    }

    private Notification buildNotification(boolean blocked) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openIntent = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, BlockVpnService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = blocked ? "الإنترنت محجوب" : "ساعة ويفصل: العدّاد شغّال";
        String body = blocked ? "اضغط تشغيل الإنترنت لإلغاء الحجب" : "هيتم حجب الإنترنت عند انتهاء الوقت المحدد";
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.saaweyefsel.app.R.drawable.ic_app)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        blocked ? "تشغيل الإنترنت" : "إلغاء العدّاد", stopIntent).build())
                .build();
    }
}
